package com.ocbc.soa.web.rest;
import com.netflix.config.DynamicPropertyFactory;
import com.netflix.config.DynamicStringProperty;

import com.ocbc.soa.web.rest.errors.BadRequestAlertException;
import com.ocbc.soa.web.rest.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;



/**
 * REST controller for managing EmpService.
 */
@RestController("endpoint.url")
@RequestMapping("/api")
	
public class EmpServiceResource {

    private final Logger log = LoggerFactory.getLogger(EmpServiceResource.class);

    private static final String ENTITY_NAME = "sbServiceOneEmpService";

    
    
	/*
	 * @Value("${endpoint.url:not found!}") private String endointURL;
	 */
    
    private DynamicStringProperty endointURLDyanamic = DynamicPropertyFactory.getInstance()
            .getStringProperty("endpoint.url", "not found!");

   
    
    /**
     * GET  /emp-services/:id : get the "id" empService.
     *
     * @param id the id of the empService to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the empService, or with status 404 (Not Found)
     */
    @GetMapping("/getProperties")
    public String getProperties() {
        log.debug("REST request to getCostCentre : {}");
        String res=endointURLDyanamic.getName() + ": " + endointURLDyanamic.get();
        
        return res;
    }
    
    
}
