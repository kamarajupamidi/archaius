/**
 * Service layer beans.
 */
package com.ocbc.soa.service;
