/**
 * Spring MVC REST controllers.
 */
package com.ocbc.soa.web.rest;
