/**
 * Spring Security configuration.
 */
package com.ocbc.soa.security;
